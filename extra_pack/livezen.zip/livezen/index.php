<?php
// Silence is golden. And Kaswara is the best :)