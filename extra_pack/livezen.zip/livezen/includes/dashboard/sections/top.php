<style type="text/css">#wpcontent,#wpbody-content{padding-left: 0px!important; padding-bottom: 0px!important; height: 100%; overflow: visible;}#wpfooter{display: none;}</style>
<div class="kswr-dash-top">
	<div class="kswr-dash-logo"></div>
	<div class="kswr-dash-title">Dashboard.</div>
</div>
<div class="kswr-dash-popupmenu">
	<div class="kswr-menu-closer"></div>
	<div class="kswr-dash-nav"></div>
</div>
<div class="kswr-dash-content">
	
</div>







